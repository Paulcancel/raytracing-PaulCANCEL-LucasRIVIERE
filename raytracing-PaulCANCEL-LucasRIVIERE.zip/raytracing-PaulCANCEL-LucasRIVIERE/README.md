# raytracing-PaulCANCEL-LucasRIVIERE

## Projet Raytracer 

## To launch :

```
mvn clean package
```

```
java -jar ./target/raytracing-paulcancel-lucasriviere.jar [your_scene_file]
```

## To test :

```
mvn test
```